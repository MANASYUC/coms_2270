package lab1;

public class Greeter {
	public static void main(String args[]) {
		System.out.println("Hello, Steve");	
	}
}
